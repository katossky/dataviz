
library(xlsx)
library(lubridate)
library(magrittr)
library(dplyr)
library(ggplot2)
library(scales)
library(stringr)
library(tidyverse)

#chemin a modifier pour charger les donn�es
setwd('P:/id1067/DataVis')

# Récupération des données d'après l'image 
unemploy <- c(7000000, 9000000, 13500000, 15000000)
date <- c('01/12/07','01/09/08', '01/03/09', '01/06/10')

# Changement de classe pour la date
dates <- as.Date(date, "%d/%m/%y")
donne <- data.frame(unemploy, dates)

# Graphe à partir des données récupérées sur l'image
donne %>% 
  ggplot(aes(x=dates, y=unemploy, group = 1)) +
  geom_point() +
  geom_line() + 
  # Adaptation des axes : Dates pour les abscisses, nombre de chômeurs pour les ordonnées 
  scale_x_date(name = NULL, date_breaks = "3 month", date_minor_breaks = "month", date_labels = "%m/%y") +
  scale_y_continuous(name = NULL, labels = scales:::number) +
  theme_bw() +
  # Étiquettes pour faciliter la lecture
  geom_text(aes(label = c('7 MIL','9 MIL','13.5 MIL', '15 MIL')),nudge_y = 300000,nudge_x = -27) +
  labs(
    title    =
      "La hausse du ch�mage, continue depuis 2008, marque le \npas � l'automne 2009 aux Etats-Unis",
    subtitle =
      "Nombre de ch�meurs pour quatre date al�atoires",
    caption =
      "Source: Bureau of Labor Statistics"
  )



# Graphique avec vrai donnees du BLS
donnees <- read.xlsx(file="Unmployement_BLS.xlsx",sheetIndex = 1,header = TRUE)
donnees %>% 
  ggplot(aes(x=Mois, y=Chomeurs, group = 1)) +
  geom_point() +
  geom_line() + 
  scale_x_date(name = NULL, date_breaks = "3 month", date_minor_breaks = "month", date_labels = "%m/%y") +
  scale_y_continuous(name = NULL, labels = scales:::number) +
  theme_bw() +
  labs(
    title    =
      "La hausse du chômage, continue depuis 2008, marque le pas à \nl'automne 2009 aux Etats-Unis",
    subtitle =
      "Nombre de chômeurs en milliers",
    caption =
      "Source : Bureau of Labor Statistics - Current Population Survey \n Champ : Personnes âgées de 16 ans et plus - Etats-Unis"
        
  )
